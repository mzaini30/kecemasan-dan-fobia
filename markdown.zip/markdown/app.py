lokasi = "/sdcard/python/markdown/"
enter = "\n\n"

def gabung(pertama, *sisanya):
    hasil = []
    hasil.append(pertama.read())
    for x in sisanya:
        hasil.append(enter)
        hasil.append(x.read())
    hasil = "".join(hasil)
    output.write(hasil)

with open(lokasi+"kecemasan.txt") as kecemasan,\
open(lokasi+"prolog.txt") as prolog,\
open(lokasi+"fobia.txt") as fobia,\
open(lokasi+"daftar pustaka.txt") as daftarpustaka,\
open(lokasi+"bin/index.html", "w") as output,\
open(lokasi+"_component/header.txt") as header,\
open(lokasi+"_component/footer.txt") as footer:

    gabung(header, prolog, kecemasan, fobia, daftarpustaka, footer)

    print
    print "done"